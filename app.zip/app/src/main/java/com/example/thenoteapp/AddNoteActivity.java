package com.example.thenoteapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddNoteActivity extends AppCompatActivity {

    private EditText titleEditText;
    private EditText contentEditText;
    private RadioGroup priorityRadioGroup;
    private Button saveButton;
    private DatabaseHelper dbHelper;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(this, "Fehler: Benutzer nicht gefunden", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        titleEditText = findViewById(R.id.editText_note_title);
        contentEditText = findViewById(R.id.editText_note_content);
        priorityRadioGroup = findViewById(R.id.radioGroup_priority);
        saveButton = findViewById(R.id.button_save_note);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveNote();
            }
        });
    }

    private void saveNote() {
        String title = titleEditText.getText().toString().trim();
        String content = contentEditText.getText().toString().trim();

        if (title.isEmpty() || content.isEmpty()) {
            Toast.makeText(this, "Bitte Titel und Inhalt eingeben", Toast.LENGTH_SHORT).show();
            return;
        }

        int priority = getSelectedPriority();
        String currentDate = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date());

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NOTE_USER_ID, userId);
        values.put(DatabaseHelper.COLUMN_NOTE_TITLE, title);
        values.put(DatabaseHelper.COLUMN_NOTE_CONTENT, content);
        values.put(DatabaseHelper.COLUMN_NOTE_PRIORITY, priority);
        values.put(DatabaseHelper.COLUMN_NOTE_DATE, currentDate);

        long newRowId = db.insert(DatabaseHelper.TABLE_NOTES, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Notiz gespeichert", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Fehler beim Speichern der Notiz", Toast.LENGTH_SHORT).show();
        }
    }

    private int getSelectedPriority() {
        int selectedId = priorityRadioGroup.getCheckedRadioButtonId();
        if (selectedId == R.id.radioButton_high) {
            return 1;
        } else if (selectedId == R.id.radioButton_medium) {
            return 2;
        } else if (selectedId == R.id.radioButton_low) {
            return 3;
        }
        return 2; // Default to Medium
    }
}
