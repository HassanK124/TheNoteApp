package com.example.thenoteapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import com.example.thenoteapp.NoteAdapter;
import com.example.thenoteapp.DatabaseHelper;
import com.example.thenoteapp.Note;
import com.example.thenoteapp.EditNoteActivity;
import com.example.thenoteapp.AddNoteActivity;

public class MainActivity extends AppCompatActivity implements NoteAdapter.OnNoteClickListener {

    private RecyclerView notesRecyclerView;
    private NoteAdapter noteAdapter;
    private List<Note> noteList;
    private DatabaseHelper dbHelper;
    private long userId;
    private static final int ADD_NOTE_REQUEST = 1;
    private static final int EDIT_NOTE_REQUEST = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId == -1) {
            finish();
            return;
        }

        notesRecyclerView = findViewById(R.id.recyclerView_notes);
        FloatingActionButton fabAddNote = findViewById(R.id.fab_add_note);

        noteList = new ArrayList<>();
        noteAdapter = new NoteAdapter(this, noteList, this);
        notesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        notesRecyclerView.setAdapter(noteAdapter);

        fabAddNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddNoteActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivityForResult(intent, ADD_NOTE_REQUEST);
            }
        });

        loadNotesFromDatabase();
    }

    private void loadNotesFromDatabase() {
        noteList.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                DatabaseHelper.COLUMN_NOTE_ID,
                DatabaseHelper.COLUMN_NOTE_TITLE,
                DatabaseHelper.COLUMN_NOTE_CONTENT,
                DatabaseHelper.COLUMN_NOTE_PRIORITY,
                DatabaseHelper.COLUMN_NOTE_DATE
        };

        String selection = DatabaseHelper.COLUMN_NOTE_USER_ID + " = ?";
        String[] selectionArgs = { String.valueOf(userId) };

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_NOTES,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_TITLE));
            String content = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_CONTENT));
            int priority = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_PRIORITY));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_DATE));
            noteList.add(new Note(id, title, content, priority, date));
        }
        cursor.close();
        noteAdapter.notifyDataSetChanged();
    }

    @Override
    public void onNoteClick(Note note) {
        Intent intent = new Intent(MainActivity.this, EditNoteActivity.class);
        intent.putExtra("NOTE_ID", note.getId());
        startActivityForResult(intent, EDIT_NOTE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_NOTE_REQUEST && resultCode == RESULT_OK) {
            loadNotesFromDatabase();
        } else if (requestCode == EDIT_NOTE_REQUEST && resultCode == RESULT_OK) {
            loadNotesFromDatabase();
        }
    }
}
