package com.example.thenoteapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.example.thenoteapp.DatabaseHelper;

public class EditNoteActivity extends AppCompatActivity {

    private EditText titleEditText;
    private EditText contentEditText;
    private RadioGroup priorityRadioGroup;
    private Button saveButton;
    private Button deleteButton;
    private DatabaseHelper dbHelper;
    private long noteId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        dbHelper = new DatabaseHelper(this);
        noteId = getIntent().getLongExtra("NOTE_ID", -1);

        if (noteId == -1) {
            Toast.makeText(this, "Fehler: Notiz nicht gefunden", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        titleEditText = findViewById(R.id.editText_note_title);
        contentEditText = findViewById(R.id.editText_note_content);
        priorityRadioGroup = findViewById(R.id.radioGroup_priority);
        saveButton = findViewById(R.id.button_save_note);
        deleteButton = findViewById(R.id.button_delete_note);

        loadNoteData();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveNoteChanges();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteNote();
            }
        });
    }

    private void loadNoteData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseHelper.COLUMN_NOTE_TITLE,
                DatabaseHelper.COLUMN_NOTE_CONTENT,
                DatabaseHelper.COLUMN_NOTE_PRIORITY
        };
        String selection = DatabaseHelper.COLUMN_NOTE_ID + " = ?";
        String[] selectionArgs = { String.valueOf(noteId) };

        Cursor cursor = db.query(DatabaseHelper.TABLE_NOTES, projection, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_TITLE));
            String content = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_CONTENT));
            int priority = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTE_PRIORITY));

            titleEditText.setText(title);
            contentEditText.setText(content);
            setSelectedPriority(priority);
            cursor.close();
        }
    }

    private void saveNoteChanges() {
        String title = titleEditText.getText().toString().trim();
        String content = contentEditText.getText().toString().trim();

        if (title.isEmpty() || content.isEmpty()) {
            Toast.makeText(this, "Bitte Titel und Inhalt eingeben", Toast.LENGTH_SHORT).show();
            return;
        }

        int priority = getSelectedPriority();
        String currentDate = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date());

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NOTE_TITLE, title);
        values.put(DatabaseHelper.COLUMN_NOTE_CONTENT, content);
        values.put(DatabaseHelper.COLUMN_NOTE_PRIORITY, priority);
        values.put(DatabaseHelper.COLUMN_NOTE_DATE, currentDate);

        String selection = DatabaseHelper.COLUMN_NOTE_ID + " = ?";
        String[] selectionArgs = { String.valueOf(noteId) };

        int count = db.update(DatabaseHelper.TABLE_NOTES, values, selection, selectionArgs);

        if (count > 0) {
            Toast.makeText(this, "Änderungen gespeichert", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Fehler beim Speichern der Änderungen", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteNote() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = DatabaseHelper.COLUMN_NOTE_ID + " = ?";
        String[] selectionArgs = { String.valueOf(noteId) };

        int deletedRows = db.delete(DatabaseHelper.TABLE_NOTES, selection, selectionArgs);

        if (deletedRows > 0) {
            Toast.makeText(this, "Notiz gelöscht", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Fehler beim Löschen der Notiz", Toast.LENGTH_SHORT).show();
        }
    }

    private int getSelectedPriority() {
        int selectedId = priorityRadioGroup.getCheckedRadioButtonId();
        if (selectedId == R.id.radioButton_high) {
            return 1;
        } else if (selectedId == R.id.radioButton_medium) {
            return 2;
        } else if (selectedId == R.id.radioButton_low) {
            return 3;
        }
        return 2; // Default to Medium
    }

    private void setSelectedPriority(int priority) {
        if (priority == 1) {
            priorityRadioGroup.check(R.id.radioButton_high);
        } else if (priority == 2) {
            priorityRadioGroup.check(R.id.radioButton_medium);
        } else if (priority == 3) {
            priorityRadioGroup.check(R.id.radioButton_low);
        }
    }
}