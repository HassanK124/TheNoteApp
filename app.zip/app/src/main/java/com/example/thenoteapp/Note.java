package com.example.thenoteapp;

public class Note {
    private long id;
    private String title;
    private String content;
    private int priority;
    private String date;

    public Note(long id, String title, String content, int priority, String date) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.priority = priority;
        this.date = date;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public int getPriority() {
        return priority;
    }

    public String getDate() {
        return date;
    }
}
