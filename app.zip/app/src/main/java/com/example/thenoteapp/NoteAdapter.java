package com.example.thenoteapp;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import com.example.thenoteapp.Note;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private Context context;
    private List<Note> noteList;
    private OnNoteClickListener listener;

    public interface OnNoteClickListener {
        void onNoteClick(Note note);
    }

    public NoteAdapter(Context context, List<Note> noteList, OnNoteClickListener listener) {
        this.context = context;
        this.noteList = noteList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.note_item, parent, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = noteList.get(position);
        holder.title.setText(note.getTitle());
        holder.content.setText(note.getContent());
        holder.date.setText(note.getDate());

        switch (note.getPriority()) {
            case 1: // High
                holder.noteItemLayout.setBackgroundColor(Color.parseColor("#FFCDD2")); // Light Red
                break;
            case 2: // Medium
                holder.noteItemLayout.setBackgroundColor(Color.parseColor("#FFF9C4")); // Light Yellow
                break;
            case 3: // Low
                holder.noteItemLayout.setBackgroundColor(Color.parseColor("#C8E6C9")); // Light Green
                break;
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onNoteClick(note);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView title, content, date;
        LinearLayout noteItemLayout;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.textView_note_title);
            content = itemView.findViewById(R.id.textView_note_content);
            date = itemView.findViewById(R.id.textView_note_date);
            noteItemLayout = itemView.findViewById(R.id.note_item_layout);
        }
    }
}
